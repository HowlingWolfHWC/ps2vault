1. Rename your favorite file to SMS.lng (case sensitive!!!);
2. Copy it to mc0:/SMS;
3. Select it in the SMS menu;

Authors are:

SMS.lng_CZ - GogLoid+NuClear
SMS.lng_DE - Quant/Jones23
SMS.lng_EN - EEUG
SMS.lng_ES - Mr.Worm~~/suloku/ftoledo
SMS.lng_FR - boule
SMS.lng_IT - Forrest/Power-ITA
SMS.lng_NL - broodje
SMS.lng_PL - emcepl/Ameagaru/Szafran/pele144
SMS.lng_PT - .../klot
SMS.lng_PT-BR - Firehawk+elchevive+Leandro Santos Vercoza
SMS.lng_TR - LaptoniC
SMS.lng_RU - pvc1
SMS.lng_CA - raparici/suloku
SMS.lng_ID - orangpelupa
SMS.lng_SK - Mirec32
SMS.lng_UA - R3ALIST
SMS.lng_BG - Dean Kasabow
SMS.lng_SE - dlanor
SMS.lng_HU - Delirious

Special thanks to Ronald Andersson ('dlanor')
for notes and corrections.

Sorry, but author's information is incomplete,
I've lost it somewhere in the forums. Please,
correct me if I was wrong here.
