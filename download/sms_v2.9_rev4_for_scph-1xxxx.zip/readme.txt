This is a hacked copy of SMS Version 2.9 Revision 4 that should work on ALL existing retail Playstation 2s.

-------------
NOTE!!:

If you have a Japanese SCPH-10000 or SCPH-15000 console,
you are required to place a copy of rom0:LIBSD from a NEWER console that has this file
into the SAME folder where you're launching this ELF from as LIBSD.irx. It's case sensitive.

(E.g. if you place the ELF into mass:, you must place rom0:LIBSD from a newer console as mass:LIBSD.irx.)

If you have a newer console, you should be able to run this version of SMS without any extra files.

FREESD DOESN'T WORK WITH THIS HACKED VERSION OF SMS!!!!

Please do NOT bundle this hacked copy of SMS with that LIBSD file, because it's a COPYRIGHTED file from SONY!!

-------------
NOTE 2!!:

If you're using a SCPH-10000 and/or a SCPH-15000 Playstation 2, the only places where this version of SMS will probably work when launched would be mc0:, mc1:, mass: and probably cdrom0: too.
If you're using a newer Playstation 2, it should work when launched from any location.


I'VE ONLY TESTED THIS ON MY SCPH-10000, LAUNCHING IT FROM MASS: !!
It works on my SCPH-77006 when launched from mass: too.

-------------
SMS belongs to it's original creators, so credit goes to the original creator (I'm just a guy who extended his work). :)

Regards,
-SP193
2010/10/24