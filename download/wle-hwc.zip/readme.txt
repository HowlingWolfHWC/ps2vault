Allows reading DVD Video discs.

Mod by: Howling Wolf and Chelsea
Special thanks: Fnaf Guy21, Keego, kHn, ffgriever