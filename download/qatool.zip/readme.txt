PS2 Memory Card Utility (QATOOL)
================================

This image is already MODE2FORM1... just burn, load using Swap Magic v2.0 CD Disc or your fav PS2 mod-chip, and enjoy this rare release from friends of www.ps2ownz.com in 420 places! :]-~

Gr33ts
------
For all your PS2 warez needs contact Nick Van Veen aka Sjeep using sjeep@gamebase.ca or in #PS2-Emulation or #ps2dev on IRC EFNet!  Spect0r is ~nickvv@202-0-34-227.cable.paradise.net.nz






