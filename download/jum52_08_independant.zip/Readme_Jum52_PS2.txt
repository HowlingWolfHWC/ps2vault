Jum's A5200 Emulator, PS2 MC-Only Version 0.8a
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

25 October 2004

This is an Atari 5200 emulator for PS2, designed to run off the memory 
card using the "PS2 Independance" exploit.

The 6502 CPU emulator source is heavily based on a distribution
by Neil Bradley. The POKEY sound emulator is a modified version 
of Ron Fries POKEY emulator.
The rest is by me, using Bigboy's PS2 framework as a starting point :)


Obligatory Copyright Notice:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Jum's A5200 Emulator is copyright 1999-2002 by James Higgs.
POKEY Sound is copyright 1996 by Ron Fries.

Jum's A5200 Emulator is free as long as it is not used in a commercial
matter and not altered in any way. The contents of this archive should
not be added to or changed in any way. 

I maintain the right to forbid the use of the emulator at
any time. I am not responsible for any damage caused by the use
of this program. This program is distributed "as-is". I make no
guarantees as to it's accuracy, performance, or compatibility with
the user's hardware.

Jum's A5200 Emulator ("Jum52") is not to be included in CD collections
of any sort. If you paid anything for Jum52, then you got ripped off!


******************************************************************
	DO NOT ASK ME FOR ROM OR CARTRIDGE IMAGES !!!
******************************************************************

Changes:
~~~~~~~

1. Incorporated Jum52 v0.8a updates
	- better collision detection
	- more accurate ANTIC cycle counting
	- some games broken, but more fixed
2. Converted PS2 code to use ps2sdk 1.1
3. Memcard handling for load/save state
4. Removed CD handling code.
5. Implemented player 2 controller :)
6. Modified to run off the MC



Compatibility:
~~~~~~~~~~~~~~

Most carts will run. These games give problems:

Decathlon
Mr. Do's Castle (corrupt rom dump)
Quest for Quintana Roo
Rescue on Fractalus

I recommend these games (off the top of my head):
River Raid
Robotron		(Use Analog mode + Robotron mode)
Space Dungeon		(Use Analog mode + Robotron mode)
Beamrider
Millipede
Pacman
Ms Pacman
Super Pacman
Pacman Jr
Missile Command
Dig Dug
Frogger



Dual-Shock Controls:
~~~~~~~~~~~~~~~~~~~

START		5200 Start button
SELECT		Go to Options Menu
TRIANGLE	5200 * button
SQUARE		5200 # button

Player 1:
~~~~~~~~~
D-PAD		Up/Down/Left/Right
X		Fire
O		Trigger ("fire 1")
R2              Side button ("fire 2")
L1		Keypad button 1
L2		Keypad button 2
R1		Keypad button 3

Player 2:
~~~~~~~~

D-PAD		Up/Down/Left/Right
X		Fire
O		Trigger ("fire 1")
R2              Side button ("fire 2")
L1		Keypad button 1
L2		Keypad button 2
R1		Keypad button 3

Note that the lack of a keypad on the PS2 controller means that some 
games are unplayable, including Star Raiders unfortunately :{


Joystick Modes:
~~~~~~~~~~~~~~

From the Options Menu (press SELECT button), select whether to use the D-PAD
or the Analog Stick for control, by toggling "Controller Mode" (press RIGHT on
the D-PAD).

Robotron / Space Dungeon control can be selected from the Options Menu too. In 
this mode, both 5200 analog controller 1 and 2 are mapped to the dual shock in 
port 1. This allows you to use the left analog stick to move, and right analog 
stick to fire in Robotron and Space Dungeon).

Pengo control mode can be activated to make Pengo and maybe some other games 
playable.

Many games do "auto-calibrating" while you play. Moving the joystick handle in 
a big circle while chanting "work dammit" usually gets it working OK. Also it 
sometimes helps if you leave the analog stick in the central position when 
starting a game.

If you activate Analog controller mode, and the game does not control as
expected, then try reloading the game.
 

Getting started (MC Version):
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

I'm too lazy to put together a CDR that will install Jum52i on your PS2 memcard. Hopefully some nice person will do it for me :)

This is what you need:

1. The PS2 independance exploit installed on your memcard
2. PS2MENU or equivalent installed as your BOOT.ELF
3. A directory called "JUM52" on your memcard, with some Atari 5200 ROMS in it.
4. The elf executable "JUM52I.ELF" or "JUM52NI.ELF" some where on your memcard where you can execute it with PS2MENU or equivalent (I put my JUM52I.ELF in BEDATA-SYSTEM (where BOOT.ELF is)

Then boot your PS2 into PS2MENU, and run the JUM52I.ELF. It will look in the JUM52 directory on MC 1 for ROMS.


NOTE: IF YOU DO NOT HAVE THE PS2 INDEPENDANCE EXPLOIT, THEN YOU CANNOT 
      RUN Jum52I ON YOUR PS2 !!!



******************************************************************
	DO NOT ASK ME FOR ROM OR CARTRIDGE IMAGES !!!
******************************************************************



FAQ:
~~~~

1. Q: It doesn't run on my Mac
   A: Get the Mac version from www.bannister.org
      (It's also available for QNX and BeOS)

2. Q: It's crap. There's no blah blah yadda yadda ...
   A: It's free. Waddaya expect?

3. Q: It's so sssslllllooooowwwwwwwww...........
   A: Your PS2 is broken.
   A: Run your PS2 emulator on a faster PC.
   A: You may be playing a NTSC game on a PAL PS2.
      (Will probably implement a PAL/NTSC switch later).

4. Q: I have trouble getting my joystick to work.
   A: It happens to even the best of men.
   A: See the stuff about "auto-calibrating above".
   A: Joystick is not completely emulated.

5. Q: I don't hear any sound.
   A: Cut down on the heavy metal.
   A: Turn up the volume REALLY loud.

6. Q: Game X doesn't work.
   A: It may be a corrupt/bad ROM image (there are many).
   A: If you can't get past the start screen in the game,
      then Jum52 just doesn't handle that game (yet).

7. Q: Where can I get ROMZ? (plead/whine/grovel/demand)
   A: Learn to use a search engine, or something.



Troubleshooting and Comments:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Email:  james7780@yahoo.com

1. RTFM ("Getting started" above)
2. Intelligent questions are welcome.
3. Constructive comments are appreciated (especially comments on
   how the emulator differs from the real thing).


Future Features:
~~~~~~~~~~~~~~~~

1. Better.
2. Faster.
3. Better controller support.
4. Memcard-runnable version? Oh wait, this is it!
5. Whatever you can suggest? 


Credits:
~~~~~~~~
Thanks to:
Dan Boris (author of VSS and V7800) for infos.
Ron Fries (for POKEY emu).
Neil Bradley for 6502 emu.
Sherwood for helpful comments and other stuff.
Christpher Durante for useful input.
Richard Bannister for cross-platform conversion and Mac version

PS2 Credits:
~~~~~~~~~~~

Guichi for encouraging me to get it working on PS2 (and for the CD cover?).
Sjeep for helping with some PS2 bugs, and for SJPCM audio streamer.
Bigboy for the PS2 framework stuff.
Hiryu for LIBCDVD.
The makers of ps2lib and ps2sdk - we appreciate your hard work.
mrbrown for the memcard exploit.
Duke/NPM, Jules and other ppl from #psx2dev and #ps2dev.
Lukasz for tip about using mrborwn's sbv patches.
Other people who helped, contributed or complained. 

