﻿The "NHDDL020NIGHTLY" has NHDDL 0.2.0 and neutrino 20240902-c8c265ff.
This is the latest neutrino's development build, which could be unstable.

The "NHDDL020STABLE" has NHDDL 0.2.0 and neutrino v1.3.1
This is the latest neutrino's stable build, but lacks of some recent functions.

Pick one and you're good to go!