MC Formatter
by consoleworld team
CODE: weltall
GFX: c0d3x
----------------------------------------------------------------
1.0b
----
-bugfixes
-a window asking if you are sure to do the selected operation to avoid accidental formattation
-italian in readme
-a estaer egg :)
-updated graphic
-built with the latest sdk

This is a simple mc formatter, it can format or unformat a mc in the
first and second memory card slot.
WARNING:
formattation or unformattation of your memory card will make you
LOST ALL FILES so backup all your files before activating the format/unformat functions of this program.
then after you formatted/unformatted your mc  you can return on your boot manager on some of these path:
mc0:/BOOT/BOOT.ELF
mc0:/BEDATA-SYSTEM/BOOT.ELF
mc0:/BADATA-SYSTEM/BOOT.ELF
if not found anything it will go to ps2 browser

keys:
START -> Return to browser
L1 -> Format MC0
L2 -> Unformat MC0
R1 -> Format MC1
R2 -> Unformat MC1

-------------------------------------
1.0b
----
-bug fix
-Una finestra che chiede se si � sicuri di fare l'operazione scelta
-Aggiunto l'italiano nel readme
-un easter egg :)
-grafica aggiornata
-compilato con l'ultimo sdk


Questo � un semplice formattatore di mc, pu� formattare e deformattare l'mc 
nel primo e nel secondo slot.
ATTENZIONE:
La formattazione e la deformattazione della memory card far� PERDERE TUTTI I FILE quindi
prima di attivare queste funzioni si consiglia di fare un backup di tutti i dati.
Una volta fatto quello che si voleva fare � possibile tornare al boot manager presente in una di
queste cartelle:
mc0:/BOOT/BOOT.ELF
mc0:/BEDATA-SYSTEM/BOOT.ELF
mc0:/BADATA-SYSTEM/BOOT.ELF
se non vengono trovate si ritorner� al browser della ps2

Tasti:
START -> Ritorna al browser
L1 -> Formatta MC0
L2 -> Deformatta MC0
R1 -> Formatta MC1
R2 -> Deformatta MC1

LICENCE:
This application is distribuited as freeware, you can distribuite and copy it as long you don't
alter any file of the archive and the archive itself, also you need to refer to the 
original site (www.consoleworld.org) and to the author (weltall).
I don't take any responsability of any direct or indirect damage done after the use of this application.