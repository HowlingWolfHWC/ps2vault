                         - MCard Killer by Vector -                          

                                  CREDITS                                    
-----------------------------------------------------------------------------
 - PS2Lib PS2 kernel library by Sjeep, Gustavo Scotti, Hiryu, mrbrown,
      Oobles, Pukko and others
 - ito by Jules and others

                                  GREETZ                                    
-----------------------------------------------------------------------------
 guichi, gothi, herben, sjeep, [ro]man and anybody else that forgot to mention..
