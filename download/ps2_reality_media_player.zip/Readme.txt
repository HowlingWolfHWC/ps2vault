Historical archive of PS2 Reality Media Player official releases and mods.

The "Pro" versions has these features:
Support for CD-Audio
Support for CDROM
Support for NETWORK (ps2VFS)
Support for MASS (it needs I modulate usbd.irx external)
Support for HDD
Support for users of PS2LINUX with possibility of loading from mc or pendrive and an extra for European with the Network the Disc Access of SCEE