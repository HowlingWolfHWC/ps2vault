Jum's A5200 Emulator, PS2 Version 0.7 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

15 September 2002

This is an Atari 5200 emulator for PS2.

The 6502 CPU emulator source is heavily based on a distribution
by Neil Bradley. The POKEY sound emulator is a modified version 
of Ron Fries POKEY emulator.
The rest is by me, using Bigboy's PS2 framework :)


Obligatory Copyright Notice:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Jum's A5200 Emulator is copyright 1999-2002 by James Higgs.
POKEY Sound is copyright 1996 by Ron Fries.

Jum's A5200 Emulator is free as long as it is not used in a commercial
matter and not altered in any way. The contents of this archive should
not be added to or changed in any way. 

I maintain the right to forbid the use of the emulator  at
any time. I am not responsible for any damage caused by the use
of this program. This program is distributed "as-is". I make no
guarantees as to it's accuracy, performance, or compatibility with
the user's hardware.

Jum's A5200 Emulator ("Jum52") is not to be included in CD collections
of any sort.


******************************************************************
	DO NOT ASK ME FOR ROM OR CARTRIDGE IMAGES !!!
******************************************************************

What's new:
~~~~~~~~~~

Some small fixes:
1. Implemented ANTIC mode 4/5 alternate colour bit.
2. Improved joystick code, implemented Pengo mode joystick.
3. Included PAL, NTSC and AUTO versions of the executable.

What's not fixed:
~~~~~~~~~~~~~~~~

CDROM doesn't stop spinning.

Compatibility:
~~~~~~~~~~~~~~

Most carts will run. These games give problems:

Decathlon
Mr. Do's Castle
Quest for Quintana Roo
Rescue on Fractalus


Dual-Shock Controls:
~~~~~~~~~~~~~~~~~~~

START		5200 Start button
SELECT		Go to Options Menu
TRIANGLE	5200 * button
SQUARE		5200 # button

Player 1:
~~~~~~~~~
D-PAD		Up/Down/Left/Right
X		Fire
O		Trigger ("fire 1")
R2              Side button ("fire 2")
L1		Keypad button 1
L2		Keypad button 2
R1		Keypad button 3

Player 2:
~~~~~~~~

Not supported yet!


Joystick:
~~~~~~~~~

From the Options Menu (press SELECT button), select whether to use the D-PAD
or the Analog Stick for control, by toggling "Controller Mode" (press RIGHT on
the D-PAD).

Robotron / Space Dungeon control mode can be activated while in Analog mode by 
selecting Robotron Mode On in the Options Menu. This allows you to use the 
left analog stick to move, and right analog stick to fire. 

Pengo control mode is activated automatically if you load Pengo. You can also 
activate it from the Options Menu. Some other games may work better with this
mode. 

Many games do "auto-calibrating" while you play. Moving the joystick handle in 
a big circle while chanting "work dammit" usually gets it working OK. Some 
games also calibrate the centre position of the joystick at the start of the 
game or at the start of a level, so you may have to be careful to leave the 
joystick centred when pressing start. 


Getting started:
~~~~~~~~~~~~~~~~

You will need:
A PS2
The files in this package, along with some 16k or 32k Atari 5200 cartridge 
images, cut correctly to CD.

NOTE: IF YOU DO NOT HAVE A WAY TO BOOT A CDR, THEN YOU CANNOT 
      RUN Jum52 ON YOUR PS2 !!!

When creating and burning the CDR, remember:

1.  Rename your roms to DOS 8.3 format
2.  To edit FILES.TXT to match your roms and directories 
3.  Check your SYSTEM.CNF points to the correct .ELF
3.  ISO Mode 2 CDROM-XA, Level 1 filenames

Use whatever works for you.

I use BIG.DAT and DUMMY.ZIP from the AR2 CD, placed before any others on the CDR 
to make sure the SYSTEM.CNF is on LBA 12231. Seems to work best with my 
AR2/modchip boot method.

The format of the FILES.TXT file is the same as that in Sjeep's PSMS 
emulator package, except that you must put the device specifier "cdrom0:" as a 
prefix in your ROM paths. See the included FILES.TXT as an example.

There are 3 versions of the JUM52 executable (NTSC, PAL and AUTO) included. 
Rename the one you want to JUM52.ELF before burning.



******************************************************************
	DO NOT ASK ME FOR ROM OR CARTRIDGE IMAGES !!!
******************************************************************



FAQ:
~~~~

1. Q: It doesn't run on my Mac.
   A: Get the Mac version from www.bannister.org

2. Q: It's crap. There's no blah blah yadda yadda ...
   A: It's free. Waddaya expect?

3. Q: It's so sssslllllooooowwwwwwwww...........
   A: Your PS2 is broken.
   A: Run your PS2 emulator on a faster PC.
   A: You may be playing a NTSC game in PAL mode. Using jum52_NTSC.elf.

4. Q: I have trouble getting my joystick to work.
   A: It happens to even the best of men. 
   A: Joystick is not completely emulated.

5. Q: I don't hear any sound.
   A: Cut down on the heavy metal.
   A: Turn up the volume REALLY loud.

6. Q: Game X doesn't work.
   A: It may be a corrupt/bad ROM image (there are many).
   A: If you can't get past the start screen in the game,
      then Jum52 just doesn't handle that game (yet).

7. Q: Where can I get ROMZ? (plead/whine/grovel/demand)
   A: Learn to use a search engine, or something.



Troubleshooting and Comments:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Email:  james7780@yahoo.com

1. RTFM ("Getting started" above)
2. Intelligent questions are welcome.
3. Constructive comments are appreciated (especially comments on
   how the emulator differs from the real thing).


Future Features:
~~~~~~~~~~~~~~~~

1. Better.
2. Faster.
3. Better controller support.
4. Whatever you can suggest? 


Credits:
~~~~~~~~
Thanks to:
Dan Boris (author of VSS and V7800) for infos.
Ron Fries (for POKEY emu).
Neil Bradley for 6502 emu.
Sherwood for helpful comments and other stuff.
Christpher Durante for useful input.
Richard Bannister for cross-platform conversion and Mac version
Sjeep & Bigboy for the PS2 stuff.
Duke/NPM & ppl from #psx2dev.
Other people who contributed or complained. 

