================================
= Memory Card Annihilator v1.0 =
================================

1.) Sprawy prawie prawne:

a. Zabrania si� modyfikowania i rozpowszechniania zmodyfikowanych wersji oprogramowania.
b. Zezwala si� na nieodp�atne u�ytkowanie i rozpowszechnianie oprogramowania z wy��czeniem zastosowa� komercyjnych.
c. Odst�pstwo od punktu c mo�liwe tylko i wy��cznie za pisemn� zgod� autor�w.
d. Powiesimy za jaja ka�dego, kto nie dostosuje si� do trzech powy�szych punkt�w (dla kobiet wymy�limy inn� tortur�).
e. Autor nie ponosi odpowiedzialno�ci za ewentualne szkody powsta�e w wyniku u�ytkowania tego oprogramowania.

2.) Opis programu

MCAnnihilator jest odpowiedzi� na problemy wynikaj�ce z u�ytkowania wielkorozmiarowych kart pami�ci niekt�rych producent�w. MCA jest aplikacj� dzia�aj�c� na niskim poziomie. Pozwala na formatowanie i odformatowywanie kart pamieci a tak�e tworzenie i wczytywanie ich obraz�w. Obs�uguje zar�wno karty PSX (1Mbit) jak i PS2 (8-128MB w trybie GUI oraz dowolny rozmiar w trybie wiersza polece�).

> Szczeg�owy przewdnik po programie dost�pny pod adresem:
http://konsole.cdrinfo.pl/artykuly/PS2-memory-card-annihilator/

3.) Klawiszologia

D-PAD poruszanie si� w menu, wyb�r opcji, wyb�r tryb�w.
X - zatwierdzanie
Tr�jk�t - anulowanie, wyj�cie z menu

4.) Funkcje

Formatowanie. Dost�pne tryby pe�ny i szybki.

Odformatowywanie. Przywr�cenie karty do stanu sprzed pierwszego formatowania. Mo�na j� nast�pnie sformatowa� w browserze lub grach.

Tworzanie obrazu karty pami�ci. Tworzy obraz karty pami�ci na jednym z dost�pnych no�nik�w (mass i hdd dla GUI oraz dodatkowo host dla wersji cmd). Obrazy zapisywane s� w formacie raw.

Wczytywanie obrazu karty pami�ci. Wczytuje obraz karty pami�ci z jednego z dost�pnych no�nik�w (mass i hdd dla GUI oraz dodatkowo host dla wersji cmd). Obrazy kart ps2 w formacie raw lub pcsx2. Dla kart psx w jednym z kilku najpopularniejszych format�w (mem, mcr, mcd, gme, psx i wielu innych).

5.) Opcje wiersza polece�.

-port=
"slot" do kt�rego w�o�ona jest karta (lub wpi�ty multitap)

-slot=
"slot" multitapa, do kt�rego w�o�ona jest karta

-fformat
szybkie formatowanie

-nformat
pe�ne formatowanie

-unformat
odformatowywanie

-make_img=
tworzenie obrazu w miejscu wskazanym przez �cie�k�

-restore_img=
wczytywanie obrazu z miejsca wskazanego przez �cie�k�

-no_iopreset
brak restu IOP

-forcepsx
wymuszenie wykrycia karty psx

-forceps2
wymuszenie wykrycia karty ps2

-tpages=
zmiana ilo�ci stron na karcie (w przypadku z�ego wykrywania przez kart�)
-tblocks=
zmiana ilo�ci blok�w na karcie (w przypadku z�ego wykrywania przez kart�) - zamienne z -tpages

Poni�sze aktywne tylko wraz z -forceps2
-bsize=
wielko�� bloku w stronach

-psize=
wielko�� strony w bajtach

-mcflags=
opcje karty pami�ci (domy�lnie 0x2b)

6.) Podzi�kowania

Dla wszystkich, kt�rzy zaanga�owali si� w sesj� zdj�ciow� swoich kart, a w szczeg�lno�ci PiotrowiB.

7.) Kontakt

Mo�na nas spotka� na:

> ffgriever
http://psx-scene.com/forums/
http://forums.ps2dev.org/
http://www.konsola.pl/forum/
http://forum.cdrinfo.pl/

> berion
http://psx-scene.com/forums/
http://www.konsola.pl/forum/
http://forum.cdrinfo.pl/
http://www.psxextreme.info/index.php
http://www.nesforum.e9.pl/
http://www.psxdev-pl.yoyo.pl/forum/
