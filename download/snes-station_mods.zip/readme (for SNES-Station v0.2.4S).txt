I have decided to work on an update for the old SnesStation emulator, based on the old work by Mega Man. Ideally, a new emulator should be written so that it will be easier to maintain it (unless SnesStation is really that perfect!), but that will take too long.

Features, as of v0.2.4S 2016/05/09:

    Updated to use the latest FILEXIO, IOMAN, USBD, USBHDFSD, HDD and PFS modules from the PS2SDK.
    No dependency on libhdd.
    No dependency on the obsolete usbmass library.
    Updated CDVD IRX (overlay module by Hiryu) module (no more freezing when there is no disc inserted).
    Built-in support for USB mass storage devices and the HDD unit.
    On-the-fly patching, so that it is easier to update the patch.
    IOP Reset fix (missing synchronization).
    No dependency on the mainboard-specific modules (i.e. XSIO2MAN, LIBSD), for compatibility with all PlayStation 2 models.
    Support for interlaced video modes.
    Added option for controlling the interlace option.
    Interlaced NTSC/PAL is used by default.
    Added an option to exit.
    Added help text for the exit option.
    Re-added the file filter for ROMs.


Credits:

    SnesStation development team for SnesStation.
    Mega Man for the original patch.
    Hiryu and Sjeep for their CDVD library.
